# Intro 
This project manages a sandbox for redis 

# Usage
```bash
  $ bundle install 
  $ librarian-puppet install 
  $ vagrant up
```
